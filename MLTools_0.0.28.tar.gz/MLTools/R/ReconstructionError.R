#' Reconstruction error of a clustering
#'
#' @description function to calculate the reconstruction error of the clusters
#' @param centers \code{dataframe} coordinates of centers of the clusters
#' @param clusters \code{char vector} cluster classification of the data
#' @param data \code{dataframe} data used to calculate the clusters
#' @export Reconstruction.Error
Reconstruction.Error <- function(centers,clusters,data){
  if(ncol(data) > 1) {
    data <- as.data.frame(data)
  }
  # number of clusters
  nc <- nrow(centers)
  # create function for squared errors
  sse <- function(x,c) sum(apply(x,1, function(x) x - c)^2)
  # Compute sse for each cluster
  sse.c <- matrix(ncol = nc,nrow = 1)
  for (i in 1:nc){
    sse.c[i] <- sse(data[clusters==i,],as.matrix(centers[i,]))
  }
  Rec.Err <- sum(sse.c)
  return(Rec.Err)
}
