#' Printing several series in variable size interval
#'
#' @param series \code{data.frame} data to be plotted
#' @param interval \code{integer} number of series to be plotted at the same time
#' @param xlab \code{character} lab of the x-axis
#' @param ylab \code{character} lab of the y-axis
#' @param title \code{character} title of the plots
#' @param end \code{integer} last pca plotted. By default is the last component
#' @param begin \code{integer} first pca plotted. By default is the first component
#' @export matplot.all
matplot.all <- function(series = NULL, interval = 5, xlab = NULL, ylab = NULL,
                        title = NULL, begin = NULL, end = NULL) {
  if (is.null(fdata) || (length(fdata) != 1 && !is.list(fdata))) {
    stop("Enter correct series data")
  }

  if ((!is.null(xlab) &&
       !is.character(xlab)) || (!is.null(ylab) && !is.character(ylab)) ||
      (!is.null(title) && !is.character(title))) {
    stop("Labs and title must be characters")
  }

  if (interval <= 0) {
    stop("Interval must be greater than zero")
  }
  # Check for tibbles
  series <- as.data.frame(series)
  if (!is.null(end)) {
    series <- series[1:end]
  }
  if (!is.null(begin)) {
    series <- series[begin:length(series)]
  }
  #Calculate loop length
  loop_length <- floor(length(series) / interval)
  rest_loop <- length(series) - loop_length * interval
  count <- 1

  for (i in 1:loop_length) {
    matplot(
      t(as.matrix(fdata[count:(count + interval - 1), ])),
      type = "l",
      xlab = xlab,
      ylab = ylab,
      main = title
    )
    count <- count + interval
    response <- readline(prompt = "Click any key to continue\n")
  }
  if (rest_loop != 0) {
    matplot(
      t(as.matrix(fdata[count:(count + rest_loop - 1), ])),
      type = "l",
      xlab = xlab,
      ylab = ylab,
      main = title
    )
  }
}
