#' Function for checking for outliers and substitute them
#' The arguments are the dataframe and the variable that is checked. The method
#' to substitute the outliers can be NA, mean, median, or predict new values.
#' It doesn't work with factor or characters variables.
#' @param fdata \code{data.frame} with the variables needed
#' @param var_name \code{character} name of the variable to be processed
#' @return \code{data.frame} with the variables processed
#' @export processOutlierandNAs
processOutlierandNAs <- function(fdata = NULL, var_name = NULL) {
  #Check for the ggplot library
  existe <- require(ggplot2)
  if (existe == FALSE){
    install.packages("ggplot2",dep=TRUE)
    library(ggplot2)
  }
  #Check for the gridExtra library
  existe <- require(gridExtra)
  if (existe == FALSE){
    install.packages("gridExtra",dep=TRUE)
    library(gridExtra)
  }

  #Check that the data provided is correct
  if(is.null(fdata)||!is.data.frame(fdata)){
    print("Please, provide a valid data frame")

  } else if(is.null(var_name) || !is.character(var_name)){
    print("Please, especify the name of the output of the data")

  } else {
    dataf <- fdata
    #Check if there are NAs in the variable
    na_orig <- sum(is.na(dataf[,var_name]))
    #Calculate the mean of the variable with outliers
    mean_orig <- mean(dataf[,var_name], na.rm = TRUE)
    #First plots with outliers
    boxplot_orig <- ggplot(fdata, aes(x = fdata[,var_name], y = fdata[,var_name])) +
      geom_boxplot(alpha = 0.8, fill = "blue", notch = TRUE) +
      labs(x = var_name, y = NULL,
           title = paste(paste("Distribution of ", var_name), "with outliers"))
    hist_orig <- ggplot(fdata, aes(x = fdata[,var_name], y = ..count..)) +
      geom_histogram(alpha = 0.8, fill = "blue",color = "black") +
      labs(x = var_name, y = NULL, title = paste(paste("Distribution of ", var_name), "with outliers"))
    #Identify the outliers
    outlier <- boxplot.stats(dataf[,var_name])$out
    #Check the mean of the outliers
    mean_outliers <- mean(outlier)
    #Check how many outliers are
    count_outliers <- length(outlier)
    cat("Outliers identified: ", count_outliers, "\n")
    #Check proportion of outliers
    cat("Proportion (%) of outliers:", round((count_outliers - na_orig) / (length(dataf[,var_name]))*100, 1), "\n")
    #Check mean of the outliers
    cat("Mean of the outliers:", round(mean_outliers, 2), "\n")
    #Choose the method for dealing with outliers
    method <- readline(prompt=paste(paste("Which method do you want to use to process outliers of variable",
                                          var_name),"? [NA, mean (m1), median (m2), predict (pred)]: "))
    #List of plots created
    plotlist <- list()
    plotlist[[1]] <- boxplot_orig
    plotlist[[2]] <- hist_orig

    if(method == "NA" || method == "N"){
      #Substitute the outliers with NAs
      dataf[,var_name] <- ifelse(dataf[,var_name] %in% outlier, NA, dataf[,var_name])
      #Check the new distributions without outliers
      boxplot_proc <- ggplot(dataf, aes(x = dataf[,var_name], y = dataf[,var_name])) +
        geom_boxplot(alpha = 0.8, fill = "red", notch = TRUE) +
        labs(x = var_name, y = NULL,
             title = paste(paste("Distribution of ", var_name), "without outliers"))
      hist_proc <- ggplot(dataf, aes(x = dataf[,var_name], y = ..count..)) +
        geom_histogram(alpha = 0.8, fill = "red",color = "black") +
        labs(x = var_name, y = NULL, title = paste(paste("Distribution of ", var_name), "without outliers"))
      #Mean of the data without outlies
      mean_proc <- mean(dataf[,var_name], na.rm = TRUE)
      cat("Mean without substituting outliers: ", round(mean_orig, 2), "\n")
      cat("Mean if we substitute outliers: ", round(mean_proc, 2), "\n")
      plotlist[[3]] <- boxplot_proc
      plotlist[[4]] <- hist_proc
      #Plot the graphics created
      grid.arrange(grobs = plotlist, nrows = 2, ncols = 2)
      response <- readline(prompt="Do you want to remove outliers and to substitute with NA? [yes/no]: ")

    } else if(method == "mean" || method == "m1"){
      #Substitute the outliers with mean
      dataf[,var_name] <- ifelse(dataf[,var_name] %in% outlier, NA, dataf[,var_name])
      dataf[,var_name] <- ifelse(is.na(dataf[,var_name]), mean(dataf[,var_name], na.rm = TRUE), dataf[,var_name])
      #Check the new distributions without outliers
      boxplot_proc <- ggplot(dataf, aes(x = dataf[,var_name], y = dataf[,var_name])) +
        geom_boxplot(alpha = 0.8, fill = "red", notch = TRUE) +
        labs(x = var_name, y = NULL,
             title = paste(paste("Distribution of ", var_name), "without outliers"))
      hist_proc <- ggplot(dataf, aes(x = dataf[,var_name], y = ..count..)) +
        geom_histogram(alpha = 0.8, fill = "red",color = "black") +
        labs(x = var_name, y = NULL, title = paste(paste("Distribution of ", var_name), "without outliers"))
      #Mean of the data without outliers
      mean_proc <- mean(dataf[,var_name])
      cat("Mean without substituting outliers: ", round(mean_orig, 2), "\n")
      cat("Mean if we substitute outliers: ", round(mean_proc, 2), "\n")
      plotlist[[3]] <- boxplot_proc
      plotlist[[4]] <- hist_proc
      #Plot the graphics created
      grid.arrange(grobs = plotlist, nrows = 2, ncols = 2)
      response <- readline(prompt="Do you want to remove outliers and to substitute with the mean? [yes/no]: ")

    } else if(method == "median" || method == "m2") {
      #Substitute the outliers with median
      dataf[,var_name] <- ifelse(dataf[,var_name] %in% outlier, NA, dataf[,var_name])
      dataf[,var_name] <- ifelse(is.na(dataf[,var_name]), median(dataf[,var_name], na.rm = TRUE), dataf[,var_name])
      #Check the new distributions without outliers
      boxplot_proc <- ggplot(dataf, aes(x = dataf[,var_name], y = dataf[,var_name])) +
        geom_boxplot(alpha = 0.8, fill = "red", notch = TRUE) +
        labs(x = var_name, y = NULL,
             title = paste(paste("Distribution of ", var_name), "without outliers"))
      hist_proc <- ggplot(dataf, aes(x = dataf[,var_name], y = ..count..)) +
        geom_histogram(alpha = 0.8, fill = "red",color = "black") +
        labs(x = var_name, y = NULL, title = paste(paste("Distribution of ", var_name), "without outliers"))
      #Mean of the data without outliers
      mean_proc <- mean(dataf[,var_name])
      cat("Mean without substituting outliers: ", round(mean_orig, 2), "\n")
      cat("Mean if we substitute outliers: ", round(mean_proc, 2), "\n")
      plotlist[[3]] <- boxplot_proc
      plotlist[[4]] <- hist_proc
      #Plot the graphics created
      grid.arrange(grobs = plotlist, nrows = 2, ncols = 2)
      response <- readline(prompt="Do you want to remove outliers and to substitute with the median? [yes/no]: ")

    } else if(method == "predict" || method == "pred"){
      #Check for the mice library
      existe <- require(mice)
      if (existe == FALSE){
        install.packages("mice",dep=TRUE)
        library(mice)
      }
      pred_method <- readline(prompt="Choose the method for prediction [pmm, midastouch, sample, cart, rf]: \n")
      #Substitute the outliers with predictions
      dataf[,var_name] <- ifelse(dataf[,var_name] %in% outlier, NA, dataf[,var_name])
      dataf[,var_name] <- complete(mice(dataf, method = pred_method, seed = 150))[,var_name]
      #Check the new distributions without outliers
      boxplot_proc <- ggplot(dataf, aes(x = dataf[,var_name], y = dataf[,var_name])) +
        geom_boxplot(alpha = 0.8, fill = "red", notch = TRUE) +
        labs(x = var_name, y = NULL,
             title = paste(paste("Distribution of ", var_name), "without outliers"))
      hist_proc <- ggplot(dataf, aes(x = dataf[,var_name], y = ..count..)) +
        geom_histogram(alpha = 0.8, fill = "red", color = "black") +
        labs(x = var_name, y = NULL, title = paste(paste("Distribution of ", var_name), "without outliers"))
      #Mean of the data without outliers
      mean_proc <- mean(dataf[,var_name])
      cat("Mean without substituting outliers: ", round(mean_orig, 2), "\n")
      cat("Mean if we substitute outliers: ", round(mean_proc, 2), "\n")
      plotlist[[3]] <- boxplot_proc
      plotlist[[4]] <- hist_proc
      #Plot the graphics created
      grid.arrange(grobs = plotlist, nrows = 2, ncols = 2)
      response <- readline(prompt="Do you want to remove outliers and to substitute with the predictions? [yes/no]: ")

    } else {
      response <- "no"
    }

    if(response == "y" | response == "yes"){
      #Substitute the values with the values calculated
      cat("Outliers successfully substituted", "\n\n")
      return(invisible(dataf[,var_name]))
    } else{
      cat("Nothing changed", "\n\n")
      return(invisible(fdata[,var_name]))
    }
  }
}
#' Process all outliers of the data.frame
#' @param fdata \code{data.frame} with the variables to be processed
#' @param factor_lev \code{integer} threshold of unique values to classify a variable as factor
#' @return \code{data.frame} with the variables processed
#' @export processAllOutlierandNAs
processAllOutlierandNAs <- function(fdata = NULL, factor_lev = 7){
  nvars <- length(fdata)
  dataf <- fdata
  for(i in 1:nvars){
    var_factor <- is.factor(dataf[,i])||is.character(dataf[,i])||(nlevels(as.factor(dataf[,i]))<factor_lev)
    if(!var_factor){
      cat("Variable: ", colnames(dataf)[i],"\n")
      dataf[,i] <- processOutlierandNAs(dataf, var_name = colnames(fdata)[i])
    }
  }
  return(invisible(dataf))
}
